<ul class="x-navigation x-navigation-horizontal x-navigation-panel">
    <!-- ESCONDER SIDEBAR -->
    <li class="xn-icon-button">
        <a href="#" class="x-navigation-minimize"><span class="fa fa-dedent"></span></a>
    </li>
    <!-- ESCONDER SIDEBAR -->                  
    <!-- SALIR / BLOQUEAR -->
    <li class="xn-icon-button pull-right last">
        <a href="#"><span class="fa fa-power-off"></span></a>
        <ul class="xn-drop-left animated zoomIn">
            <li><a href="lock.php"><span class="fa fa-lock"></span> Bloquear Pantalla</a></li>
            <li><a href="#" class="mb-control" data-box="#mb-signout"><span class="fa fa-sign-out"></span> Salir</a></li>
        </ul>                        
    </li> 
    <li class="xn-icon-button pull-right">
        <a href="#"><span class="fa fa-home"></span></a>
        <ul class="xn-drop-left animated zoomIn">
            <li><a href="../" target="_blank">Ver sitio Web <i class="fa fa-arrow-circle-o-right" aria-hidden="true"></i></a></li>
        </ul>                        
    </li> 
    <!-- SALIR / BLOQUEAR -->                  
</ul>