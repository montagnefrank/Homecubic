<div class="page-sidebar page-sidebar-fixed scroll mCustomScrollbar _mCS_1 mCS-autoHide">
    <ul class="x-navigation">
        <li class="xn-logo">
            <a href="#" gotopanel='home' class="menu_btn"> Homecubic</a>
            <a href="#" class="x-navigation-control"></a>
        </li>
        <li class="xn-profile">
            <a href="#" class="profile-mini">
                <img src="<?php
                $isavatar = "assets/img/users/" . $user . ".jpg";
                if (file_exists($isavatar)) {
                    echo "assets/img/users/" . $user;
                } else {
                    echo "assets/img/users/default";
                }
                ?>.jpg" alt="<?php echo $user ?>"/>
            </a>
            <div class="profile">
                <div class="profile-image">
                    <img src="<?php
                    $isavatar = "assets/img/users/" . $user . ".jpg";
                    if (file_exists($isavatar)) {
                        echo "assets/img/users/" . $user;
                    } else {
                        echo "assets/img/users/default";
                    }
                    ?>.jpg" alt="<?php echo $user ?>"/>
                </div>
                <div class="profile-data">
                    <div class="profile-data-name">
                        <?php
                        echo $_SESSION['username'];
                        ?>
                        <div class="profile-data-title">
                            <span class="fa fa-user"></span> 
                            <?php echo $user ?></div>
                    </div>
                    <div class="profile-data-title">
                        <span class="fa fa-industry"></span> 
                        <?php
                        echo 'HomeCubic';
                        ?>
                    </div>
                </div>
                <div class="profile-controls">
<!--                    <a href="pages-profile.html" class="profile-control-left"><span class="fa fa-info"></span></a>
                    <a href="pages-messages.html" class="profile-control-right"><span class="fa fa-envelope"></span></a>-->
                </div>
            </div>                                                                        
        </li>
        <li class="xn-title">Menú principal</li>
        <li class="xn-openable"><a href="#"><span class="fa fa-television"></span><span class="xn-text"> Website</span></a>
            <ul>
                <li><a href="#" gotopanel='header' class="menu_btn"> Header</a></li>
                <li><a href="#" gotopanel='frase' class="menu_btn"> Pensamiento</a></li>
                <li><a href="#" gotopanel='about' class="menu_btn"> Quienes Somos</a></li>
                <li><a href="#" gotopanel='tweets' class="menu_btn"> Testimonios</a></li>
                <li><a href="#" gotopanel='prov' class="menu_btn"> Proveedores</a></li>
                <li><a href="#" gotopanel='port' class="menu_btn"> Portafolio</a></li>
                <li><a href="#" gotopanel='blog' class="menu_btn"> Blog</a></li>
            </ul>
        </li>  
        <li><a href="#" gotopanel='contact' class="menu_btn"><span class="fa fa-user-circle"></span><span class="xn-text"> Contacto</span></a></li>
        <li><a href="#" gotopanel='tools' class="menu_btn"><span class="fa fa-cogs"></span><span class="xn-text"> Herramientas</span></a></li>
    </ul>
</div>